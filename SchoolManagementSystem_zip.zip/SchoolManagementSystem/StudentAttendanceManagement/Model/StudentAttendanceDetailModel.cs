﻿namespace StudentAttendanceManagement.Model
{
    public class StudentAttendanceDetailModel
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public double AttendancePercentage { get; set; }
    }
}
