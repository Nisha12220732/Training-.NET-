﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentAttendanceManagement.Model;

namespace StudentAttendanceManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentAttendanceController : ControllerBase
    {
        [HttpGet]
        public IEnumerable<StudentAttendanceDetailModel> Get()
        {
            var obj1 = new StudentAttendanceDetailModel() { StudentId = 1, StudentName = "Anu", AttendancePercentage = 78.5 };
            var obj2 = new StudentAttendanceDetailModel() { StudentId = 2, StudentName = "Anuj", AttendancePercentage = 88.5 };

            List<StudentAttendanceDetailModel> lis2 = new List<StudentAttendanceDetailModel> { obj1, obj2 };
            return lis2;
        }
    }
}
