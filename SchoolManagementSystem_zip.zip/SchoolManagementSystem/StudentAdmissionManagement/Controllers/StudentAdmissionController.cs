﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentAdmissionManagement.Models;

namespace StudentAdmissionManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentAdmissionController : ControllerBase
    {
        [HttpGet]
        public IEnumerable<StudentAdmissionDetailsModel> Get()
        {
            var obj1 = new StudentAdmissionDetailsModel() { StudentId = 1 , StudentName = "Anu" , DateOfJoining = DateTime.Now, StudentClass = "K2203"};
            var obj2 = new StudentAdmissionDetailsModel() { StudentId = 2, StudentName = "Anuj", DateOfJoining = DateTime.Now, StudentClass = "K2204" };

            List<StudentAdmissionDetailsModel> lis = new List<StudentAdmissionDetailsModel> { obj1, obj2 };
            return lis;



        }
    }
}
